# your_app/templatetags/custom_filters.py

from django import template
from datetime import datetime

register = template.Library()

@register.filter
def time_diff_in_words(date1, date2):
    """Calculates the time difference in human-readable format."""
    if not date1 or not date2:
        return ''
    
    # Ensure both dates are in datetime format
    if isinstance(date1, str):
        date1 = datetime.strptime(date1, '%Y-%m-%d %H:%M:%S')  # Adjust format if necessary
    if isinstance(date2, str):
        date2 = datetime.strptime(date2, '%Y-%m-%d %H:%M:%S')  # Adjust format if necessary
    
    # Calculate the difference in time
    diff = date2 - date1
    seconds = diff.total_seconds()

    if seconds >= 86400:  # 1 day = 86400 seconds
        return f"{int(seconds // 86400)} d"
    elif seconds >= 3600:  # 1 hour = 3600 seconds
        return f"{int(seconds // 3600)} hr"
    elif seconds >= 60:  # 1 minute = 60 seconds
        return f"{int(seconds // 60)} min"
    else:
        return f"{int(seconds)} sec"
